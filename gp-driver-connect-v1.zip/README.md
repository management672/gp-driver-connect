# G&P Driver Connect

A mobile-friendly driver and dispatch portal for G&P LOGISTICS LLC.

## Included in this starter
- Driver view showing only the current active load
- Load status updates
- POD upload
- Dispatch load creation and assignment
- Dispatch-only rate confirmation upload
- Driver pay per load
- Weekly payroll summary
- Local demo data so the app works immediately after deployment
- Supabase schema for production database setup

## Deploy
1. Upload the extracted project files to the root of the GitHub repository.
2. Commit the files.
3. In Vercel, connect the repository or redeploy the existing project.
4. The app runs in demo mode immediately.

## Demo access
Choose either Driver or Dispatch on the home screen. No password is required in demo mode.

## Production database
Create a Supabase project, run `supabase/schema.sql`, create two private Storage buckets named:
- `pod-documents`
- `rate-confirmations`

Then add these Vercel environment variables:
- `NEXT_PUBLIC_SUPABASE_URL`
- `NEXT_PUBLIC_SUPABASE_PUBLISHABLE_KEY`

The current UI uses browser storage for immediate testing. Supabase integration is the next implementation step after deployment and testing.
